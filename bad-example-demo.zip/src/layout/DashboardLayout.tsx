import type { ReactNode } from 'react'

type DashboardLayoutProps = {
  children: ReactNode
  header: ReactNode
  sidebar: ReactNode
}

function DashboardLayout({ children, header, sidebar }: DashboardLayoutProps) {
  return (
    <div className="min-h-screen px-4 py-4 sm:px-6 lg:px-8">
      <div className="dashboard-shell mx-auto flex min-h-[calc(100vh-2rem)] max-w-[1600px] flex-col rounded-[36px] border border-white/60 bg-white/65 p-3 shadow-[0_30px_80px_rgba(18,74,114,0.18)] backdrop-blur xl:p-4">
        {header}
        <div className="mt-3 grid flex-1 gap-3 xl:grid-cols-[280px_minmax(0,1fr)]">
          {sidebar}
          <main
            id="main-content"
            className="glass-panel rounded-[32px] border border-white/70 p-4 shadow-[inset_0_1px_0_rgba(255,255,255,0.85)] sm:p-6"
          >
            {children}
          </main>
        </div>
      </div>
    </div>
  )
}

export default DashboardLayout