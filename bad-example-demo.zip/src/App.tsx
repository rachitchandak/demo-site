import AppointmentForm from './components/AppointmentForm'
import BillingTable, { type Invoice } from './components/BillingTable'
import Header from './components/Header'
import NotificationToast from './components/NotificationToast'
import PaymentModal from './components/PaymentModal'
import PharmacyAccordion, {
  type Prescription,
} from './components/PharmacyAccordion'
import RecordTabs from './components/RecordTabs'
import Sidebar from './components/Sidebar'
import DashboardLayout from './layout/DashboardLayout'
import {
  type DashboardSection,
  useDashboardState,
} from './hooks/useDashboardState'
import './styles/healthhub.css'

const invoices: Invoice[] = [
  {
    id: 'INV-4012',
    date: 'May 09, 2026',
    category: 'Cardiology Follow-up',
    amount: '$320.00',
    status: 'Outstanding',
  },
  {
    id: 'INV-4007',
    date: 'Apr 28, 2026',
    category: 'Quarterly Lab Panel',
    amount: '$185.00',
    status: 'Processing',
  },
  {
    id: 'INV-3984',
    date: 'Apr 10, 2026',
    category: 'Physical Therapy Session',
    amount: '$95.00',
    status: 'Paid',
  },
]

const prescriptions: Prescription[] = [
  {
    id: 'rx-1',
    name: 'Atorvastatin 20mg',
    dosage: '1 tablet nightly',
    refillDate: 'Jun 02, 2026',
    clinician: 'Dr. Elena Morris',
  },
  {
    id: 'rx-2',
    name: 'Metformin XR 500mg',
    dosage: '2 tablets with breakfast',
    refillDate: 'May 24, 2026',
    clinician: 'Dr. Marcus Yuen',
  },
  {
    id: 'rx-3',
    name: 'Albuterol Inhaler',
    dosage: '2 puffs as needed',
    refillDate: 'Jul 11, 2026',
    clinician: 'Dr. Priya Rao',
  },
]

const overviewCards = [
  { label: 'Upcoming Visits', value: '3', detail: 'Next with cardiology tomorrow' },
  { label: 'Open Bills', value: '$505', detail: '2 invoices due this month' },
  { label: 'Lab Status', value: 'Normal', detail: 'Metabolic panel synced at 9:14 AM' },
]

function App() {
  const {
    activeRecordTab,
    currentSection,
    expandedPrescription,
    isPaymentOpen,
    isToastVisible,
    setActiveRecordTab,
    setCurrentSection,
    closePaymentModal,
    openPaymentModal,
    showSyncToast,
    togglePrescription,
  } = useDashboardState()

  const renderSection = (section: DashboardSection) => {
    if (section === 'records') {
      return (
        <RecordTabs
          activeTab={activeRecordTab}
          onTabChange={setActiveRecordTab}
        />
      )
    }

    if (section === 'billing') {
      return <BillingTable invoices={invoices} onPayInvoice={openPaymentModal} />
    }

    if (section === 'appointments') {
      return <AppointmentForm />
    }

    if (section === 'pharmacy') {
      return (
        <PharmacyAccordion
          expandedId={expandedPrescription}
          onToggle={togglePrescription}
          prescriptions={prescriptions}
        />
      )
    }

    return (
      <section className="space-y-6">
        <div className="grid gap-4 md:grid-cols-3">
          {overviewCards.map((card) => (
            <article
              key={card.label}
              className="glass-panel rounded-[28px] border border-white/70 p-6 shadow-[0_24px_60px_rgba(14,74,120,0.12)]"
            >
              <p className="text-sm font-semibold uppercase tracking-[0.24em] text-sky-700/70">
                {card.label}
              </p>
              <p className="mt-4 text-4xl font-semibold tracking-tight text-slate-900">
                {card.value}
              </p>
              <p className="mt-2 text-sm text-slate-600">{card.detail}</p>
            </article>
          ))}
        </div>

        <div className="grid gap-6 xl:grid-cols-[1.35fr_0.95fr]">
          <RecordTabs
            activeTab={activeRecordTab}
            onTabChange={setActiveRecordTab}
          />
          <BillingTable invoices={invoices} onPayInvoice={openPaymentModal} compact />
        </div>
      </section>
    )
  }

  return (
    <>
      <DashboardLayout
        header={
          <Header
            currentSection={currentSection}
            onSync={showSyncToast}
            profileImageSrc="/doctor-profile.svg"
          />
        }
        sidebar={
          <Sidebar
            currentSection={currentSection}
            onSectionChange={setCurrentSection}
          />
        }
      >
        {renderSection(currentSection)}
      </DashboardLayout>

      <PaymentModal
        isOpen={isPaymentOpen}
        onClose={closePaymentModal}
        total="$320.00"
      />

      <NotificationToast
        isVisible={isToastVisible}
        message="Sync complete. Records refreshed successfully."
      />
    </>
  )
}

export default App
