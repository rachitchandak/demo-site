import { useEffect, useState } from 'react'

export type DashboardSection =
  | 'overview'
  | 'records'
  | 'billing'
  | 'appointments'
  | 'pharmacy'

export type RecordTab = 'summary' | 'lab-results' | 'history'

export function useDashboardState() {
  const [currentSection, setCurrentSection] =
    useState<DashboardSection>('overview')
  const [activeRecordTab, setActiveRecordTab] = useState<RecordTab>('summary')
  const [expandedPrescription, setExpandedPrescription] = useState<string | null>(
    'rx-1',
  )
  const [isPaymentOpen, setIsPaymentOpen] = useState(false)
  const [isToastVisible, setIsToastVisible] = useState(false)

  useEffect(() => {
    if (!isToastVisible) {
      return undefined
    }

    const timer = window.setTimeout(() => {
      setIsToastVisible(false)
    }, 2800)

    return () => window.clearTimeout(timer)
  }, [isToastVisible])

  const togglePrescription = (id: string) => {
    setExpandedPrescription((currentId) => (currentId === id ? null : id))
  }

  return {
    activeRecordTab,
    closePaymentModal: () => setIsPaymentOpen(false),
    currentSection,
    expandedPrescription,
    isPaymentOpen,
    isToastVisible,
    openPaymentModal: () => setIsPaymentOpen(true),
    setActiveRecordTab,
    setCurrentSection,
    showSyncToast: () => setIsToastVisible(true),
    togglePrescription,
  }
}