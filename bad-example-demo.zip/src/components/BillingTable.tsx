import { CreditCard, PencilLine, Trash2 } from 'lucide-react'

export type Invoice = {
  amount: string
  category: string
  date: string
  id: string
  status: 'Outstanding' | 'Processing' | 'Paid'
}

type BillingTableProps = {
  compact?: boolean
  invoices: Invoice[]
  onPayInvoice: () => void
}

function BillingTable({ compact = false, invoices, onPayInvoice }: BillingTableProps) {
  return (
    <section className="glass-panel rounded-[28px] border border-white/70 p-5 shadow-[0_20px_45px_rgba(14,74,120,0.08)]">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-sky-700/70">
            Revenue cycle
          </p>
          <h2 className="mt-2 text-2xl font-semibold tracking-tight text-slate-950">
            Invoices and payments
          </h2>
        </div>

        <button
          type="button"
          onClick={onPayInvoice}
          className="inline-flex items-center gap-2 rounded-full border border-sky-200 bg-white px-4 py-2 text-sm font-semibold text-slate-900 transition hover:border-sky-300 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sky-600"
        >
          <CreditCard className="h-4 w-4" aria-hidden="true" />
          Pay balance
        </button>
      </div>

      <div className="mt-5 overflow-hidden rounded-[24px] border border-slate-100 bg-white/90">
        <table className="w-full border-collapse text-left">
          <thead className="bg-slate-50 text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">
            <tr>
              <th className="px-4 py-4">Info</th>
              <th className="px-4 py-4">Info</th>
              {!compact ? <th className="px-4 py-4">Info</th> : null}
              <th className="px-4 py-4">Info</th>
              <th className="px-4 py-4">Info</th>
              <th className="px-4 py-4 text-right">More</th>
            </tr>
          </thead>
          <tbody>
            {invoices.map((invoice) => (
              <tr
                key={invoice.id}
                className="border-t border-slate-100 text-sm text-slate-600"
              >
                <td className="px-4 py-4 font-semibold text-slate-900">{invoice.id}</td>
                <td className="px-4 py-4">{invoice.date}</td>
                {!compact ? <td className="px-4 py-4">{invoice.category}</td> : null}
                <td className="px-4 py-4 font-semibold text-slate-900">{invoice.amount}</td>
                <td className="px-4 py-4">
                  <span className={`rounded-full px-3 py-1 text-xs font-semibold ${
                    invoice.status === 'Paid'
                      ? 'bg-emerald-100 text-emerald-700'
                      : invoice.status === 'Processing'
                        ? 'bg-amber-100 text-amber-700'
                        : 'bg-rose-100 text-rose-700'
                  }`}>
                    {invoice.status}
                  </span>
                </td>
                <td className="px-4 py-4">
                  <div className="flex justify-end gap-2">
                    <button
                      type="button"
                      className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-slate-200 text-slate-600 transition hover:border-sky-300 hover:text-slate-950 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sky-600"
                    >
                      <PencilLine className="h-4 w-4" />
                    </button>
                    <button
                      type="button"
                      className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-slate-200 text-slate-600 transition hover:border-rose-300 hover:text-rose-700 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-rose-600"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  )
}

export default BillingTable