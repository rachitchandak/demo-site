import { CreditCard, X } from 'lucide-react'

type PaymentModalProps = {
  isOpen: boolean
  onClose: () => void
  total: string
}

function PaymentModal({ isOpen, onClose, total }: PaymentModalProps) {
  if (!isOpen) {
    return null
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/45 px-4 backdrop-blur-sm">
      <div className="w-full max-w-md rounded-[32px] border border-white/70 bg-white p-6 shadow-[0_30px_80px_rgba(15,23,42,0.25)]">
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.24em] text-sky-700/70">
              Secure payment
            </p>
            <h2 className="mt-2 text-2xl font-semibold tracking-tight text-slate-950">
              Pay outstanding balance
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-slate-200 text-slate-600 transition hover:border-slate-300 hover:text-slate-950 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sky-600"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="mt-6 rounded-[24px] bg-sky-50 p-5">
          <p className="text-sm text-slate-500">Amount due</p>
          <p className="mt-2 text-4xl font-semibold tracking-tight text-slate-950">{total}</p>
        </div>

        <div className="mt-6 grid gap-4">
          <div>
            <input
              id="card-number"
              inputMode="numeric"
              placeholder="4242 4242 4242 4242"
              className="w-full rounded-[18px] border border-sky-100 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-sky-400"
            />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <input
                id="expiry"
                placeholder="MM/YY"
                className="w-full rounded-[18px] border border-sky-100 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-sky-400"
              />
            </div>
            <div>
              <input
                id="cvc"
                placeholder="123"
                className="w-full rounded-[18px] border border-sky-100 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-sky-400"
              />
            </div>
          </div>
        </div>

        <button
          type="button"
          className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-full bg-slate-950 px-5 py-3 text-sm font-semibold text-white shadow-[0_14px_30px_rgba(15,23,42,0.22)] transition hover:bg-slate-800 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-950"
        >
          <CreditCard className="h-4 w-4" />
          Confirm payment
        </button>
      </div>
    </div>
  )
}

export default PaymentModal