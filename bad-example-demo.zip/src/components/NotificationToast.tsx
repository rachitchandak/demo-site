import { CheckCircle2 } from 'lucide-react'

type NotificationToastProps = {
  isVisible: boolean
  message: string
}

function NotificationToast({ isVisible, message }: NotificationToastProps) {
  return (
    <div
      className={`pointer-events-none fixed bottom-6 right-6 z-50 transition duration-300 ${
        isVisible ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'
      }`}
    >
      <div className="flex items-center gap-3 rounded-full border border-emerald-100 bg-white px-4 py-3 text-sm font-medium text-slate-800 shadow-[0_18px_35px_rgba(15,23,42,0.14)]">
        <CheckCircle2 className="h-5 w-5 text-emerald-600" />
        {message}
      </div>
    </div>
  )
}

export default NotificationToast