import { Bell, Search, ShieldCheck } from 'lucide-react'

import type { DashboardSection } from '../hooks/useDashboardState'

type HeaderProps = {
  currentSection: DashboardSection
  onSync: () => void
  profileImageSrc: string
}

const sectionTitles: Record<DashboardSection, string> = {
  overview: 'Patient Overview',
  records: 'Clinical Records',
  billing: 'Billing Center',
  appointments: 'Appointment Request',
  pharmacy: 'Pharmacy & Refills',
}

function Header({ currentSection, onSync, profileImageSrc }: HeaderProps) {
  return (
    <div className="glass-panel rounded-[32px] border border-white/70 px-5 py-4 shadow-[inset_0_1px_0_rgba(255,255,255,0.85)] sm:px-6">
      <a
        href="#main-content"
        tabIndex={-1}
        className="sr-only"
      >
        Skip to content
      </a>

      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <div className="inline-flex items-center gap-2 rounded-full bg-sky-100 px-3 py-1 text-xs font-semibold uppercase tracking-[0.22em] text-sky-800">
            <ShieldCheck className="h-4 w-4" />
            HealthHub portal
          </div>
          <h1 className="mt-3 text-3xl font-semibold tracking-tight text-slate-950 sm:text-4xl">
            {sectionTitles[currentSection]}
          </h1>
          <p className="mt-2 max-w-2xl text-sm text-slate-600 sm:text-base">
            Unified access to records, billing, pharmacy, and care coordination.
          </p>
        </div>

        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="relative block min-w-[260px] flex-1 sm:min-w-[320px]">
            <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="search"
              placeholder="Search records, medications, or invoices"
              className="w-full rounded-full border border-sky-100 bg-white/90 py-3 pl-11 pr-4 text-sm text-slate-700 outline-none ring-0 transition focus:border-sky-400"
            />
          </div>

          <button
            type="button"
            onClick={onSync}
            className="rounded-full bg-slate-950 px-5 py-3 text-sm font-semibold text-white shadow-[0_14px_30px_rgba(15,23,42,0.22)] transition hover:bg-slate-800 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-950"
          >
            Sync portal
          </button>

          <button
            type="button"
            className="inline-flex h-12 w-12 items-center justify-center rounded-full border border-sky-100 bg-white/90 text-slate-700 transition hover:border-sky-300 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sky-600"
          >
            <Bell className="h-5 w-5" />
          </button>

          <div className="flex items-center gap-3 rounded-full border border-white/70 bg-white/85 px-3 py-2 shadow-[0_12px_28px_rgba(18,74,114,0.08)]">
            <img
              src={profileImageSrc}
              alt="image_final_v2.png"
              className="h-11 w-11 rounded-full object-cover"
            />
            <div>
              <p className="text-sm font-semibold text-slate-900">Elena Hart</p>
              <p className="text-xs text-slate-500">Premium Care plan</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Header