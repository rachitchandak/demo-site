import type { RecordTab } from '../hooks/useDashboardState'

type RecordTabsProps = {
  activeTab: RecordTab
  onTabChange: (tab: RecordTab) => void
}

const tabContent: Record<
  RecordTab,
  {
    body: string
    eyebrow: string
    metrics: Array<{ label: string; value: string }>
    title: string
  }
> = {
  summary: {
    eyebrow: 'Clinical summary',
    title: 'Stable cardiovascular trend with improved recovery markers',
    body:
      'Recent observations show resting heart rate returning to baseline, blood pressure within plan targets, and no newly reported symptoms after the last follow-up visit.',
    metrics: [
      { label: 'Blood pressure', value: '118 / 76' },
      { label: 'Resting HR', value: '64 bpm' },
      { label: 'Sleep score', value: '89 / 100' },
    ],
  },
  'lab-results': {
    eyebrow: 'Lab panel',
    title: 'Metabolic and lipid labs synced from April 2026 collection',
    body:
      'Hemoglobin A1c, LDL, and liver enzymes are inside the recommended threshold for the current treatment plan. Clinician notes advise continuing the existing medication cadence.',
    metrics: [
      { label: 'A1c', value: '5.8%' },
      { label: 'LDL', value: '91 mg/dL' },
      { label: 'ALT', value: '22 U/L' },
    ],
  },
  history: {
    eyebrow: 'Visit history',
    title: 'Care activity across the last 12 months remains on schedule',
    body:
      'Completed events include annual wellness screening, two physical therapy check-ins, and a cardiology follow-up with no care escalations or missed medication refills logged.',
    metrics: [
      { label: 'Annual visits', value: '6' },
      { label: 'No-show rate', value: '0%' },
      { label: 'Care gaps', value: 'None' },
    ],
  },
}

const tabs: Array<{ id: RecordTab; label: string }> = [
  { id: 'summary', label: 'Summary' },
  { id: 'lab-results', label: 'Lab Results' },
  { id: 'history', label: 'History' },
]

function RecordTabs({ activeTab, onTabChange }: RecordTabsProps) {
  const currentTab = tabContent[activeTab]

  return (
    <section className="glass-panel rounded-[28px] border border-white/70 p-5 shadow-[0_20px_45px_rgba(14,74,120,0.08)]">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-sky-700/70">
            Health record center
          </p>
          <h2 className="mt-2 text-2xl font-semibold tracking-tight text-slate-950">
            Patient records
          </h2>
        </div>
        <div className="inline-flex flex-wrap gap-2 rounded-full bg-slate-100/80 p-1">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              type="button"
              className={`cursor-pointer rounded-full border-b-2 px-4 py-2 text-sm font-semibold transition ${
                activeTab === tab.id
                  ? 'border-sky-600 bg-white text-slate-950 shadow-[0_10px_24px_rgba(15,23,42,0.12)]'
                  : 'border-transparent text-slate-500 hover:text-slate-950'
              }`}
              onClick={() => onTabChange(tab.id)}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-6 rounded-[28px] bg-[linear-gradient(180deg,rgba(255,255,255,0.96)_0%,rgba(241,248,255,0.96)_100%)] p-6">
        <p className="text-xs font-semibold uppercase tracking-[0.24em] text-sky-700/70">
          {currentTab.eyebrow}
        </p>
        <h3 className="mt-3 text-2xl font-semibold tracking-tight text-slate-950">
          {currentTab.title}
        </h3>
        <p className="mt-3 max-w-3xl text-sm leading-7 text-slate-600">
          {currentTab.body}
        </p>

        <div className="mt-6 grid gap-3 sm:grid-cols-3">
          {currentTab.metrics.map((metric) => (
            <div key={metric.label} className="rounded-[22px] bg-white/90 p-4 shadow-[0_14px_28px_rgba(14,74,120,0.08)]">
              <p className="text-xs font-semibold uppercase tracking-[0.2em] text-slate-400">
                {metric.label}
              </p>
              <p className="mt-2 text-2xl font-semibold text-slate-950">
                {metric.value}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default RecordTabs