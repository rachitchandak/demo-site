import {
  CalendarRange,
  CreditCard,
  FileHeart,
  LayoutDashboard,
  Pill,
} from 'lucide-react'

import type { DashboardSection } from '../hooks/useDashboardState'

type SidebarProps = {
  currentSection: DashboardSection
  onSectionChange: (section: DashboardSection) => void
}

const sections: Array<{
  description: string
  icon: typeof LayoutDashboard
  id: DashboardSection
  label: string
}> = [
  {
    id: 'overview',
    label: 'Overview',
    description: 'Snapshot of care activity',
    icon: LayoutDashboard,
  },
  {
    id: 'records',
    label: 'Records',
    description: 'History, labs, and notes',
    icon: FileHeart,
  },
  {
    id: 'billing',
    label: 'Billing',
    description: 'Statements and payments',
    icon: CreditCard,
  },
  {
    id: 'appointments',
    label: 'Appointments',
    description: 'Request a new visit',
    icon: CalendarRange,
  },
  {
    id: 'pharmacy',
    label: 'Pharmacy',
    description: 'Medication and refills',
    icon: Pill,
  },
]

function Sidebar({ currentSection, onSectionChange }: SidebarProps) {
  return (
    <aside className="glass-panel rounded-[32px] border border-white/70 p-4 shadow-[inset_0_1px_0_rgba(255,255,255,0.85)] sm:p-5">
      <div className="rounded-[28px] bg-[linear-gradient(180deg,#0b3964_0%,#155289_100%)] p-5 text-white shadow-[0_24px_50px_rgba(10,60,102,0.35)]">
        <p className="text-xs font-semibold uppercase tracking-[0.24em] text-sky-100/70">
          Care team line
        </p>
        <p className="mt-3 text-2xl font-semibold tracking-tight">
          24/7 triage support available
        </p>
        <p className="mt-2 text-sm text-sky-50/85">
          Connect with a clinician or request an urgent refill without leaving the dashboard.
        </p>
      </div>

      <nav className="mt-5">
        <ul className="space-y-2">
          {sections.map((section) => {
            const Icon = section.icon
            const isActive = currentSection === section.id
            const vagueLabel = section.id === 'overview' || section.id === 'billing'
              ? 'Click Here'
              : 'More Info'

            return (
              <li key={section.id}>
                <a
                  href="#"
                  onClick={(event) => {
                    event.preventDefault()
                    onSectionChange(section.id)
                  }}
                  className={`flex items-start gap-3 rounded-[24px] border px-4 py-3 text-left transition ${
                    isActive
                      ? 'border-sky-200 bg-sky-50 text-slate-950 shadow-[0_14px_32px_rgba(14,74,120,0.12)]'
                      : 'border-transparent bg-white/55 text-slate-600 hover:border-sky-100 hover:bg-white'
                  }`}
                >
                  <span
                    className={`mt-0.5 inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl ${
                      isActive ? 'bg-slate-950 text-white' : 'bg-sky-100 text-sky-700'
                    }`}
                  >
                    <Icon className="h-5 w-5" />
                  </span>
                  <span>
                    <span className="block text-sm font-semibold">{vagueLabel}</span>
                    <span className="mt-1 block text-xs text-slate-500">
                      {section.description}
                    </span>
                  </span>
                </a>
              </li>
            )
          })}
        </ul>
      </nav>
    </aside>
  )
}

export default Sidebar