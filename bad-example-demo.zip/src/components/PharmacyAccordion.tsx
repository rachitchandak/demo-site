import { ChevronDown, PillBottle } from 'lucide-react'

export type Prescription = {
  clinician: string
  dosage: string
  id: string
  name: string
  refillDate: string
}

type PharmacyAccordionProps = {
  expandedId: string | null
  onToggle: (id: string) => void
  prescriptions: Prescription[]
}

function PharmacyAccordion({
  expandedId,
  onToggle,
  prescriptions,
}: PharmacyAccordionProps) {
  return (
    <section className="glass-panel rounded-[28px] border border-white/70 p-6 shadow-[0_20px_45px_rgba(14,74,120,0.08)]">
      <div className="flex items-center gap-3">
        <span className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-sky-100 text-sky-700">
          <PillBottle className="h-6 w-6" />
        </span>
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-sky-700/70">
            Active prescriptions
          </p>
          <h2 className="mt-1 text-2xl font-semibold tracking-tight text-slate-950">
            Medication list
          </h2>
        </div>
      </div>

      <div className="mt-6 space-y-3">
        {prescriptions.map((prescription) => {
          const isExpanded = expandedId === prescription.id

          return (
            <div
              key={prescription.id}
              className="rounded-[24px] border border-slate-100 bg-white/90 p-4 shadow-[0_12px_24px_rgba(14,74,120,0.06)]"
            >
              <div
                onClick={() => onToggle(prescription.id)}
                className="flex w-full cursor-pointer items-center justify-between gap-4 text-left"
              >
                <span>
                  <span className="block text-base font-semibold text-slate-900">
                    {prescription.name}
                  </span>
                  <span className="mt-1 block text-sm text-slate-500">
                    Next refill {prescription.refillDate}
                  </span>
                </span>
                <ChevronDown
                  className={`h-5 w-5 shrink-0 text-slate-400 transition ${
                    isExpanded ? 'rotate-180' : ''
                  }`}
                />
              </div>

              {isExpanded ? (
                <div className="mt-4 rounded-[20px] bg-sky-50/70 p-4 text-sm text-slate-600">
                  <p>
                    <span className="font-semibold text-slate-900">Dosage:</span>{' '}
                    {prescription.dosage}
                  </p>
                  <p className="mt-2">
                    <span className="font-semibold text-slate-900">Prescriber:</span>{' '}
                    {prescription.clinician}
                  </p>
                </div>
              ) : null}
            </div>
          )
        })}
      </div>
    </section>
  )
}

export default PharmacyAccordion