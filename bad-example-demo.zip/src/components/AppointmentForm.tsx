import { CalendarClock } from 'lucide-react'
import { useState } from 'react'

type FormErrors = {
  date?: string
  name?: string
  reason?: string
}

function AppointmentForm() {
  const [name, setName] = useState('')
  const [date, setDate] = useState('')
  const [reason, setReason] = useState('')
  const [errors, setErrors] = useState<FormErrors>({})
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()

    const nextErrors: FormErrors = {}

    if (!name.trim()) {
      nextErrors.name = 'Enter the patient name.'
    }

    if (!date) {
      nextErrors.date = 'Select a preferred date.'
    }

    if (!reason.trim()) {
      nextErrors.reason = 'Describe the reason for the appointment.'
    }

    setErrors(nextErrors)
    setSubmitted(Object.keys(nextErrors).length === 0)
  }

  return (
    <section className="grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
      <form
        className="glass-panel rounded-[28px] border border-white/70 p-6 shadow-[0_20px_45px_rgba(14,74,120,0.08)]"
        onSubmit={handleSubmit}
        noValidate
      >
        <div className="flex items-center gap-3">
          <span className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-sky-100 text-sky-700">
            <CalendarClock className="h-6 w-6" />
          </span>
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.24em] text-sky-700/70">
              Care access
            </p>
            <h2 className="mt-1 text-2xl font-semibold tracking-tight text-slate-950">
              Request an appointment
            </h2>
          </div>
        </div>

        <div className="mt-6 grid gap-5">
          <div>
            <div className="mb-2 text-sm font-semibold text-slate-700">
              Patient name <span className="text-rose-500">*</span>
            </div>
            <input
              id="patient-name"
              value={name}
              onChange={(event) => setName(event.target.value)}
              autoComplete="name"
              className="w-full rounded-[18px] border border-sky-100 bg-white/90 px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-sky-400"
              placeholder="Enter full name"
            />
          </div>

          <div>
            <div className="mb-2 text-sm font-semibold text-slate-700">
              Preferred date <span className="text-rose-500">*</span>
            </div>
            <input
              id="preferred-date"
              type="date"
              value={date}
              onChange={(event) => setDate(event.target.value)}
              className="w-full rounded-[18px] border border-sky-100 bg-white/90 px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-sky-400"
            />
          </div>

          <div>
            <div className="mb-2 text-sm font-semibold text-slate-700">
              Reason for visit <span className="text-rose-500">*</span>
            </div>
            <textarea
              id="visit-reason"
              value={reason}
              onChange={(event) => setReason(event.target.value)}
              rows={5}
              className="w-full rounded-[18px] border border-sky-100 bg-white/90 px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-sky-400"
              placeholder="Describe symptoms, questions, or follow-up needs"
            />
          </div>
        </div>

        <div className="mt-5 min-h-6 text-sm text-rose-600">
          {errors.name || errors.date || errors.reason
            ? Object.values(errors).join(' ')
            : submitted
              ? 'Appointment request submitted for review.'
              : null}
        </div>

        <button
          type="submit"
          className="mt-4 rounded-full bg-slate-950 px-5 py-3 text-sm font-semibold text-white shadow-[0_14px_30px_rgba(15,23,42,0.22)] transition hover:bg-slate-800 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-950"
        >
          Send request
        </button>
      </form>

      <aside className="glass-panel rounded-[28px] border border-white/70 p-6 shadow-[0_20px_45px_rgba(14,74,120,0.08)]">
        <p className="text-xs font-semibold uppercase tracking-[0.24em] text-sky-700/70">
          Availability
        </p>
        <h3 className="mt-2 text-2xl font-semibold tracking-tight text-slate-950">
          Current scheduling window
        </h3>
        <div className="mt-6 space-y-3">
          {[
            ['Cardiology', 'Tomorrow, 10:30 AM'],
            ['Primary Care', 'May 18, 2:15 PM'],
            ['Nutrition', 'May 21, 9:00 AM'],
          ].map(([service, slot]) => (
            <div key={service} className="rounded-[22px] bg-sky-50/80 p-4">
              <p className="text-sm font-semibold text-slate-900">{service}</p>
              <p className="mt-1 text-sm text-slate-600">{slot}</p>
            </div>
          ))}
        </div>
      </aside>
    </section>
  )
}

export default AppointmentForm