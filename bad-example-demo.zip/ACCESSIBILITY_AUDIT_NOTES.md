# HealthHub Accessibility Audit Notes

This project intentionally includes accessibility failures for demo and tooling validation purposes.

The regressions below were introduced on purpose to exercise WCAG compliance tooling against a visually polished but programmatically inaccessible SPA.

## Scope

- App entry: `src/App.tsx`
- Components:
  - `src/components/Header.tsx`
  - `src/components/Sidebar.tsx`
  - `src/components/RecordTabs.tsx`
  - `src/components/AppointmentForm.tsx`
  - `src/components/BillingTable.tsx`
  - `src/components/PharmacyAccordion.tsx`
  - `src/components/PaymentModal.tsx`
  - `src/components/NotificationToast.tsx`

## Implemented Failure Matrix

| Area | Implemented violation | Intended effect | Likely WCAG impact | Implemented in repo |
| --- | --- | --- | --- | --- |
| Header | Skip link hidden with `tabIndex={-1}` and root changed from `header` to `div` | Keyboard users cannot reach the bypass link and landmark semantics are removed | 2.1.1 Keyboard, 2.4.1 Bypass Blocks, 1.3.1 Info and Relationships | `src/components/Header.tsx` |
| Sidebar | Semantic `nav`/list markup is kept, but section links use vague text like "Click Here" and "More Info" with no supplemental label | Navigation purpose is unclear even though structural HTML remains semantic | 2.4.4 Link Purpose, 4.1.2 Name, Role, Value | `src/components/Sidebar.tsx` |
| Record tabs | Tab triggers use real `button` elements, but no `tablist`/`tab` roles or `aria-selected` state are provided | Active state and tab behavior are only visually conveyed | 1.3.1 Info and Relationships, 4.1.2 Name, Role, Value | `src/components/RecordTabs.tsx` |
| Appointment form | Visible field text remains, but labels were replaced with plain `div` text and required state is only a red `*` | Inputs are no longer explicitly labeled and required state is only visual | 1.3.1 Info and Relationships, 3.3.2 Labels or Instructions, 4.1.2 Name, Role, Value | `src/components/AppointmentForm.tsx` |
| Appointment validation | Validation summary is rendered in a plain `div` with no live region or alert semantics | Assistive tech may not announce errors or submission state changes | 3.3.1 Error Identification, 4.1.3 Status Messages | `src/components/AppointmentForm.tsx` |
| Billing list | Semantic table markup is kept, but column headers are made vague and non-descriptive while icon-only actions remain unlabeled | Table structure exists, but header meaning and action purpose are still weak for assistive technology users | 2.4.6 Headings and Labels, 4.1.2 Name, Role, Value | `src/components/BillingTable.tsx` |
| Pharmacy accordion | Expand/collapse trigger changed from button to clickable `div` and `aria-expanded` removed | Control type and current state are not conveyed | 4.1.2 Name, Role, Value | `src/components/PharmacyAccordion.tsx` |
| Payment modal | Dialog semantics removed, auto-focus removed, and no focus trap added | Background remains tabbable and modal is not announced as a dialog | 2.4.3 Focus Order, 2.1.1 Keyboard, 4.1.2 Name, Role, Value | `src/components/PaymentModal.tsx` |
| Toast | `aria-live` removed from sync toast | Status changes are visual-only | 4.1.3 Status Messages | `src/components/NotificationToast.tsx` |
| Icon-only actions | Icon buttons for invoice actions and header notification no longer have accessible names | Purpose of controls is ambiguous to screen reader users | 4.1.2 Name, Role, Value | `src/components/BillingTable.tsx`, `src/components/Header.tsx` |
| Images | Profile image alt changed to a generic filename string | Non-text content description is unhelpful | 1.1.1 Non-text Content | `src/components/Header.tsx` |

## Component Notes

### Header

- Implemented regression: hidden skip link with `tabIndex={-1}`, non-semantic top container, unlabeled icon-only notification button, generic image alt.
- File: `src/components/Header.tsx`

### Sidebar

- Implemented regression: navigation keeps `nav` and list semantics, but link text is intentionally vague and non-descriptive.
- File: `src/components/Sidebar.tsx`

### RecordTabs

- Implemented regression: tab widgets use plain buttons and expose active state solely through a visual border, without tab roles or selection state.
- File: `src/components/RecordTabs.tsx`

### AppointmentForm

- Implemented regression: labels replaced with non-associated text, required fields only marked visually with `*`, and validation feedback rendered without alert or live-region semantics.
- File: `src/components/AppointmentForm.tsx`

### BillingTable

- Implemented regression: invoice layout uses a semantic table, but headers are intentionally vague and icon-only action buttons have no accessible labels.
- File: `src/components/BillingTable.tsx`

### PharmacyAccordion

- Implemented regression: accordion header is a clickable `div` with no `aria-expanded` state.
- File: `src/components/PharmacyAccordion.tsx`

### PaymentModal

- Implemented regression: no dialog semantics, no initial focus management, and no focus trapping.
- File: `src/components/PaymentModal.tsx`

### NotificationToast

- Implemented regression: visual-only success notification without a live region.
- File: `src/components/NotificationToast.tsx`

## Notes For Demo Use

These regressions were added for local demo validation of an accessibility compliance tool. They should not be used as a production baseline.

## Verification

- Re-run `npm run build` after changes to confirm the intentionally inaccessible demo still compiles.